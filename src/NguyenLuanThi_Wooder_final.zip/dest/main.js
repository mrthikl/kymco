AOS.init({
  duration: 500,
  once: true,
  offset: 120, // offset (in px) from the original trigger point
  delay: 150,
});

// open nav
const hambuger = document.querySelector(".hambuger span");
const nav = document.querySelector(".nav");
hambuger.addEventListener("click", function () {
  this.classList.toggle("openHamburger");
  nav.classList.toggle("openNav");
});

// scroll add background header 
const header = document.querySelector("header");
const hero = document.querySelector(".hero");
const heightHeader = header.clientHeight;
const heightHero = hero.clientHeight;

window.addEventListener("scroll", function () {
  const scrollY = window.pageYOffset;
  if (scrollY > heightHero - heightHeader) {
    header.classList.add("active");
  } else {
    header.classList.remove("active");
  }
});

// Back to top
const backToTop = document.querySelector('.backtotop');
backToTop.addEventListener("click", function () {
  window.scrollTo({
    top: 0,
  })
})

// lang
const langbtn = document.querySelector(".lang")
const langCurrent = document.querySelector(".lang__current p")
const langOption = document.querySelector(".lang__option")
const langOptionItem = document.querySelectorAll(".lang__option p")

langCurrent.addEventListener("click", function (e) {
  e.stopPropagation();
  langbtn.classList.add('active')
})

langOptionItem.forEach(function (item) {
  item.addEventListener("click", function () {
    let itemContent = this.textContent
    let currentContent = langCurrent.textContent
    langCurrent.innerHTML = itemContent
    this.innerHTML = currentContent
    langbtn.classList.remove('active')
  })

})

// popup video
const popupVideo = document.querySelector('.popup__video')
let srcVideoPopup = document.querySelector(".popup__video iframe")
// const exitPopup = document.querySelector('.exit__popup')
const videoItem = document.querySelectorAll('.video__list-item')

videoItem.forEach(function (item) {
  item.addEventListener("click", function (e) {
    e.stopPropagation();
    let urlVideo = this.getAttribute('data-url-video')
    srcVideoPopup.setAttribute('src', 'https://www.youtube.com/embed/' + urlVideo + '?autoplay=1&mute=0')
    popupVideo.classList.add('active')
  })
})
function closePopupVideo() {
  popupVideo.classList.remove('active')
  srcVideoPopup.setAttribute('src', ' ')
}
// exitPopup.addEventListener("click", function () {
//   closePopupVideo()
// })


// click menu scroll to section
const menuItem = document.querySelectorAll('.menu .ul-menu li a')
let sections = []

function removeActiveMenuItem() {
  menuItem.forEach(function (item) {
    item.classList.remove('active')
  })
}

menuItem.forEach(function (item) {
  let itemClass = item.getAttribute("href").replace('#', '')
  let urlSection = document.querySelector('.' + itemClass)
  sections.push(urlSection)
  item.addEventListener("click", function (e) {
    e.preventDefault();
    window.scroll({
      top: urlSection.offsetTop - heightHeader + 1,
    })
    removeActiveMenuItem()
    item.classList.add('active')
  })
})
window.addEventListener('scroll', function (e) {
  let scrollY = window.pageYOffset
  sections.forEach(function (item, index) {
    if (scrollY > item.offsetTop - heightHeader && scrollY < item.offsetTop + item.offsetHeight) {
      removeActiveMenuItem()
      menuItem[index].classList.add('active')
    } else {
      menuItem[index].classList.remove('active')
    }
  })
})

// slider hero
const sliderBox = document.querySelector('.slider')
const sliderList = document.querySelector('.hero__slider')
const sliderItem = document.querySelectorAll('.hero__slider-item')
const sliderButton = document.querySelectorAll('.hero__bottom-button .btn')
const sliderDotList = document.querySelectorAll('.-dotted span')
const sliderNumber = document.querySelector(".-number")
let sliderIndex = 0
let direction;

sliderItem.forEach(function (item, index) {
  if (item.classList.contains('active')) {
    sliderIndex = index;
  }
})

function numberIndex(index) {
  sliderNumber.innerHTML = (index).toString().padStart('2', '0')
}

function sliderIndexFunc(index) {
  sliderItem[sliderIndex].classList.remove('active')
  sliderDotList[index].classList.add('active')
  sliderItem[index].classList.add('active')
  sliderDotList[sliderIndex].classList.remove('active')
  numberIndex(index + 1)
  sliderIndex = index;
}

sliderDotList.forEach(function (dot, index) {
  dot.addEventListener('click', function () {
    sliderIndexFunc(index)
  })
})

sliderButton.forEach(function (button) {
  button.addEventListener('click', function () {
    if (button.classList.contains("-next")) {
      if (sliderIndex < sliderItem.length - 1) {
        sliderIndexFunc(sliderIndex + 1)
      } else {
        sliderIndexFunc(0)
      }
    } else {
      if (sliderIndex > 0) {
        sliderIndexFunc(sliderIndex - 1)
      } else {
        sliderIndexFunc(sliderItem.length - 1)
      }
    }
  })
})


// slider 2
// function changeDot() {
//   document.querySelector('.-dotted .active').classList.remove('active')
//   sliderDotList[sliderIndex].classList.add('active')
// }

// sliderButton.forEach(function (btn) {
//   btn.addEventListener('click', function () {
//     if (btn.classList.contains('-next')) {
//       sliderIndex = sliderIndex < 2 ? sliderIndex + 1 : 0
//       direction = 1;
//       sliderBox.style.justifyContent = 'flex-start';
//       sliderList.style.transform = 'translate(-33.33%)'
//     } else {
//       sliderIndex = sliderIndex > 0 ? sliderIndex - 1 : 2
//       direction = -1;
//       sliderBox.style.justifyContent = 'flex-end';
//       sliderList.style.transform = 'translate(33.33%)'
//     }
//     changeDot()
//     sliderNumber.textContent = '0' + `${sliderIndex + 1}`
//   })
// })
// sliderList.addEventListener('transitionend', function () {
//   if (direction == 1) {
//     sliderList.appendChild(sliderList.firstElementChild)
//   } else if (direction == -1) {
//     sliderList.prepend(sliderList.lastElementChild)
//   }
//   sliderList.style.transition = 'none'
//   sliderList.style.transform = 'translate(0)'
//   setTimeout(function () {
//     sliderList.style.transition = '0.5s'
//   });
// })

// sliderDotList.forEach(function (dot, index) {
//   dot.addEventListener('click', function () {
//     sliderIndex = index
//     changeDot()
//     sliderNumber.textContent = '0' + `${sliderIndex + 1} `
//     sliderList.style.transform = 'translate(' + sliderIndex * -33.33 + '%)'
//   })
// })


// slider 1
// sliderButton.forEach(function (btn) {
//   btn.addEventListener('click', function () {
//     if (btn.classList.contains('-prev')) {
//       sliderIndex = sliderIndex > 0 ? sliderIndex - 1 : 0
//       slider.style.transform = 'translate(' + sliderIndex * -33.33 + '%)'
//     } else {
//       sliderIndex = sliderIndex < 2 ? sliderIndex + 1 : 2
//       slider.style.transform = 'translate(' + sliderIndex * -33.33 + '%)'
//     }
//     changeDot()
//     sliderNumber.textContent = '0' + `${sliderIndex + 1}`
//   })
// })

// sliderDotList.forEach(function (dot, index) {
//   dot.addEventListener('click', function () {
//     sliderIndex = index
//     changeDot()
//     sliderNumber.textContent = '0' + `${sliderIndex + 1} `
//     slider.style.transform = 'translate(' + sliderIndex * -33.33 + '%)'
//   })
// })


// news content
const btnNews = document.querySelectorAll(".news .btn")
const newContent = document.querySelectorAll('.news__content')

btnNews.forEach(function (btn, index) {
  btn.addEventListener("click", function () {
    let tagNumber = index + 1
    btnNews.forEach(function (btn) {
      btn.classList.remove('active')
    })
    newContent.forEach(function (content) {
      content.classList.remove('active')
    })
    btn.classList.add('active')
    document.querySelector('.news .content-' + tagNumber).classList.add('active')
  })
})

// FAQ
const accordionItem = document.querySelectorAll('.accordion__list-item')
accordionItem.forEach(function (item) {
  item.addEventListener('click', function () {
    this.classList.toggle('active')
    if (item.style.maxHeight) {
      item.style.maxHeight = null
    } else {
      item.style.maxHeight = item.scrollHeight + 'px';
    }
  })
})

// close element
document.addEventListener("click", function () {
  closePopupVideo()
  langbtn.classList.remove('active')
})